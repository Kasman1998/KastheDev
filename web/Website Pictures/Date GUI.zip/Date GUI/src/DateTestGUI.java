

import javax.swing.JFrame;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * This class will execute the program by calling the Date class.
 * @author Kasman98
 */
public class DateTestGUI {
    /**
     * Main method is used to execute the program.
     * @param args 
     */
 public static void main(String[] args){
     /**
      * Created an object called gui from the Date class.
      */
     Date gui= new Date();
     /**
      * Tells the program to end when the window is close.
      */
     gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     /**
      * Set the size of the windows
      */
     gui.setSize(400,300);
     /**
      * Allows the user to resize window.
      */
     gui.setResizable(true);
     /**
      * Allows the user to see window.
      */
     gui.setVisible(true);
     
}
}