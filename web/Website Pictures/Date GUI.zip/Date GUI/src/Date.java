/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/

/**
 * The purpose of this program is for the user to enter a date  and
 * the the next window to tell the user what is the date.
 * @author Kwentin
 */
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
/**
 *  JFrame is extends because is a superclass. Date class is inhierting the
 * JFrame methods and variables. Date is using the ActionListener to implement
 * the  actionPerformed() method for event handling.
 * @author Kasman98
 */
public class Date extends JFrame implements ActionListener{
    private JTextField date;
    private JButton OK,cancel;
    private String welcomeLogin="Welcome to the Date Application";
    
    
    /**
     * Date constructor is build to add buttons,labels,title and to format.
     */
    public Date(){
        /**
         * Date Application is the name of the title.
         */
        super("Date Application");
        /**
         * FlowLayout() is used to format text.
         */
        setLayout(new FlowLayout(FlowLayout.CENTER));
        /**
         * date is the named of the TextField.
         */
        date=new JTextField("Please Type in Date",30);
        /**
         * Creating OK and cancel button and created button images using
         * ImageIcon() method.
         */
        OK = new JButton(new ImageIcon("src/Pictures/Yes.png"));
        cancel= new JButton(new ImageIcon("src/Pictures/No.png"));
        
        /**
         * added the date,OK, results an formatted them.
         */
        add(date);
        add(cancel,BorderLayout.EAST);
        add(OK,BorderLayout.WEST);
        OK.addActionListener(this);
        cancel.addActionListener(this);
        
        /**
         * Creating the new Icon Logo for the Welcome Screen using the ImageIcon
         * class.
         */
        
        ImageIcon icon= new ImageIcon("src/Pictures/Welcome.jpg");
        JOptionPane.showMessageDialog(null, welcomeLogin,"Welcome",JOptionPane.PLAIN_MESSAGE,icon);
    }
    /**
     * Implementing the actionPerformed() method.
     * @param dateAction
     */
    @Override
    public void actionPerformed(ActionEvent dateAction){
        /**
         * Casting the date TextField to a String.
         */
        
        String displayDate = date.getText();
        String output="";
        /**
         * No Button
         */
        ImageIcon icon2 =new ImageIcon("src/Pictures/No.png");
        
        
        /**
         * When the user press OK they output will be formatted and
         *  equal to displayDate. The text will be set for displayDate and
         * a message will be output of the date.
         */
        if(dateAction.getSource()==OK){
            output= String.format("The date enter is %s",displayDate);
            date.setText(displayDate + "");
            JOptionPane.showMessageDialog(null, output);
            /**
             * Once your date is formatted you will asked to continue. If you 
             * enter yes then you will asked to enter the month of your
             * choice. If NO then the application will close.
             */
            int user =JOptionPane.showConfirmDialog(null,"Do you want to continue (YES/NO)","User Option",JOptionPane.YES_NO_OPTION);
            if(user== JOptionPane.YES_OPTION){
                output= String.format("This section will tell your birthday symbol");
                JOptionPane.showMessageDialog(null,output);
                String birthMonth="";
                birthMonth=JOptionPane.showInputDialog("Please enter your birthday month only(Please uppercase first letter. ex.December)");
                /**
                 * The switch statement is used to as options for the user input for months.
                 * Their are 12 cases for January-December. The default case will be executed 
                 * if the user enter anything other then a month. They will get error message
                 * saying try again.Once the user enter the month they will be asked to
                 * continue to or exit.If they continue then asked enter the date of the month.
                 */
                switch(birthMonth){
                    case "January":
                        output= String.format("Your birth symbol Goats and Water Bearers");
                        JOptionPane.showMessageDialog(null,output);
                        user=JOptionPane.showConfirmDialog(null,"Do you want find out if your Goats or Water Bearers (YES/NO)","User Option",JOptionPane.YES_NO_OPTION);
                        ImageIcon icon4 =new ImageIcon("src/Pictures/Goat.png");
                        ImageIcon icon5 = new ImageIcon("src/Pictures/Water Bear.jpg");
                        if(user== JOptionPane.YES_OPTION){
                            output= String.format("This section will tell your birthday symbol");
                            JOptionPane.showMessageDialog(null,output);
                            birthMonth=JOptionPane.showInputDialog(null,"Please enter the day of the month. Example 14");
                            int birth= Integer.parseInt(birthMonth);
                            if(birth < 20){
                                JOptionPane.showMessageDialog(null,"You are a Goat","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon4);
                                break;
                            }
                            if ( birth >= 20|| birth<=31){
                                JOptionPane.showMessageDialog(null, "Your are a Water Bear","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon5);
                                break;
                            }
                             else if(birth > 30){
                                JOptionPane.showMessageDialog(null, "Please correct date","",JOptionPane.INFORMATION_MESSAGE);
                            }
                            else
                                System.exit(0);
                        }
                        break;
                    case "February":
                        output= String.format("Your birth symbol is Water Beares and Fishes ");
                        JOptionPane.showMessageDialog(null,output);
                        user=JOptionPane.showConfirmDialog(null,"Do you want find out if your Water Bearers or Fishes (YES/NO)","User Option",JOptionPane.YES_NO_OPTION);
                        if(user== JOptionPane.YES_OPTION){
                            ImageIcon icon6 = new ImageIcon("src/Pictures/Water Bear.jpg");
                            output= String.format("This section will tell your birthay day");
                            JOptionPane.showMessageDialog(null,output);
                            birthMonth=JOptionPane.showInputDialog(null,"Please enter the day of the month. Example 14");
                            int birth= Integer.parseInt(birthMonth);
                            if(birth < 19){
                                JOptionPane.showMessageDialog(null,"You are a Water Bear","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon6);
                                break;
                            }
                            if ( birth<=28){
                                ImageIcon icon7=new ImageIcon("src/Pictures/Fish.png");
                                JOptionPane.showMessageDialog(null, "Your are a Fish","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon7);
                                break;
                            }
                             else if(birth >=29){
                                JOptionPane.showMessageDialog(null, "Please correct date","Error Message",JOptionPane.INFORMATION_MESSAGE);
                            }
                            else
                                System.exit(0);
                        }
                        break;
                    case "March":
                        output= String.format("Your birth symbol is Fishes and Rams");
                        JOptionPane.showMessageDialog(null,output);
                        user=JOptionPane.showConfirmDialog(null,"Do you want find out if your Fishes and Rams (YES/NO)","User Option",JOptionPane.YES_NO_OPTION);
                        if(user== JOptionPane.YES_OPTION){
                            output= String.format("This section will tell your birthday symbol");
                            JOptionPane.showMessageDialog(null,output);
                            birthMonth=JOptionPane.showInputDialog(null,"Please enter the day of the month. Example 14");
                            int birth= Integer.parseInt(birthMonth);
                            if(birth < 20){
                                ImageIcon icon7=new ImageIcon("src/Pictures/Fish.png");
                                JOptionPane.showMessageDialog(null,"You are a Fish","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon7);
                                break;
                            }
                            if ( birth<=31){
                                ImageIcon icon8=new ImageIcon("src/Pictures/Ram.png");
                                JOptionPane.showMessageDialog(null, "Your are a Ram","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon8);
                                break;
                            }
                            else if(birth > 31){
                                JOptionPane.showMessageDialog(null,"Please enter the correct date","Error Message",JOptionPane.INFORMATION_MESSAGE);
                            }
                            else
                                System.exit(0);
                        }
                        break;
                    case "April":
                        output= String.format("Your birth month symbol is Rams and Bulls");
                        JOptionPane.showMessageDialog(null,output);
                        user=JOptionPane.showConfirmDialog(null,"Do you want find out if your Rams and Bulls (YES/NO)","User Option",JOptionPane.YES_NO_OPTION);
                        if(user== JOptionPane.YES_OPTION){
                            output= String.format("This section will tell your birthday symbol");
                            JOptionPane.showMessageDialog(null,output);
                            birthMonth=JOptionPane.showInputDialog(null,"Please enter the day of the month. Example 14");
                            int birth= Integer.parseInt(birthMonth);
                            if(birth < 20){
                                ImageIcon icon8=new ImageIcon("src/Pictures/Ram.png");
                                JOptionPane.showMessageDialog(null,"You are a Rams","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon8);
                                break;
                            }
                            if ( birth<=31){
                                ImageIcon icon9=new ImageIcon("src/Pictures/Bull.png");
                                JOptionPane.showMessageDialog(null, "Your are a Bull","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon9);
                                break;
                            }
                            else if(birth > 31){
                                JOptionPane.showMessageDialog(null, "Please enter correct date","",JOptionPane.PLAIN_MESSAGE,icon2);
                                break;
                            }
                            else
                                System.exit(0);
                        }
                        break;
                    case "May":
                        output= String.format("Your birth symbol is Bulls and Twins");
                        JOptionPane.showMessageDialog(null,output);
                        user=JOptionPane.showConfirmDialog(null,"Do you want find out if your Bulls and Twins (YES/NO)","User Option",JOptionPane.YES_NO_OPTION);
                        if(user== JOptionPane.YES_OPTION){
                            output= String.format("This section will tell your birthday symbol");
                            JOptionPane.showMessageDialog(null,output);
                            birthMonth=JOptionPane.showInputDialog(null,"Please enter the day of the month. Example 14");
                            int birth= Integer.parseInt(birthMonth);
                            if(birth < 21){
                                ImageIcon icon8=new ImageIcon("src/Pictures/Bull.png");
                                JOptionPane.showMessageDialog(null,"You are a Bulls","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon8);
                                break;
                            }
                            if ( birth<=31){
                                ImageIcon icon9=new ImageIcon("src/Pictures/Twins.jpg");
                                JOptionPane.showMessageDialog(null, "Your are a Twins","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon9);
                                break;
                            }
                            else if(birth > 31){
                                JOptionPane.showMessageDialog(null, "Please correct date","",JOptionPane.INFORMATION_MESSAGE);
                                break;
                            }
                            else
                                System.exit(0);
                        }
                        break;
                    case "June":
                        output= String.format("Your birth symbol is Twins and Crabs");
                        JOptionPane.showMessageDialog(null,output);
                        user=JOptionPane.showConfirmDialog(null,"Do you want find out if your Twins and Crabs (YES/NO)","User Option",JOptionPane.YES_NO_OPTION);
                        if(user== JOptionPane.YES_OPTION){
                            output= String.format("This section will tell your birthday symbol");
                            JOptionPane.showMessageDialog(null,output);
                            birthMonth=JOptionPane.showInputDialog(null,"Please enter the day of the month. Example 14");
                            int birth= Integer.parseInt(birthMonth);
                            if(birth <= 21){
                                ImageIcon icon9=new ImageIcon("src/Pictures/Twins.jpg");
                                JOptionPane.showMessageDialog(null,"You are a Twins","Birthday Symbols",JOptionPane.PLAIN_MESSAGE,icon9);
                                break;
                            }
                            if ( birth<=30){
                                ImageIcon icon10=new ImageIcon("src/Pictures/Crabs.png");
                                JOptionPane.showMessageDialog(null, "You are a Crab","Birthday Symbols",JOptionPane.PLAIN_MESSAGE,icon10);
                                break;
                            }
                            else if(birth > 30){
                                JOptionPane.showMessageDialog(null, "Please correct date","",JOptionPane.INFORMATION_MESSAGE);
                            }
                            else
                                System.exit(0);
                        }
                        break;
                    case "July":
                        output= String.format("Your birth symbol is Crabs and Lions");
                        JOptionPane.showMessageDialog(null,output);
                        user=JOptionPane.showConfirmDialog(null,"Do you want find out if your Crab or Lion (YES/NO)","User Option",JOptionPane.YES_NO_OPTION);
                        if(user== JOptionPane.YES_OPTION){
                            output= String.format("This section will tell your birthday symbol");
                            JOptionPane.showMessageDialog(null,output);
                            birthMonth=JOptionPane.showInputDialog(null,"Please enter the day of the month. Example 14 ");
                            int birth= Integer.parseInt(birthMonth);
                            if(birth < 22){
                                ImageIcon icon10=new ImageIcon("src/Pictures/Crabs.png");
                                JOptionPane.showMessageDialog(null,"You are a Crabs","",JOptionPane.PLAIN_MESSAGE,icon10);
                                break;
                            }
                            if (birth<=31){
                                ImageIcon icon11=new ImageIcon("src/Pictures/Lion.png");
                                JOptionPane.showMessageDialog(null, "Your are a Lion","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon11);
                                break;
                            }
                            if(birth > 31){
                                JOptionPane.showMessageDialog(null, "Please correct date","",JOptionPane.INFORMATION_MESSAGE);
                                break;
                            }
                            else
                                System.exit(0);
                        }
                        break;
                    case "August":
                        output= String.format("Your birth symbol is Lions and Virgins");
                        JOptionPane.showMessageDialog(null,output);
                    user=JOptionPane.showConfirmDialog(null,"Do you want find out if your Lions or Virgin (YES/NO)","User Option",JOptionPane.YES_NO_OPTION);
                        if(user== JOptionPane.YES_OPTION){
                            output= String.format("This section will tell your birthday symbol");
                            JOptionPane.showMessageDialog(null,output);
                            birthMonth=JOptionPane.showInputDialog(null,"Please enter the day of the month. Example 14");
                            int birth= Integer.parseInt(birthMonth);
                            if(birth < 23){
                                ImageIcon icon11=new ImageIcon("src/Pictures/Lion.png");
                                JOptionPane.showMessageDialog(null,"You are a Lion","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon11);
                                break;
                            }
                            if (birth <30){
                                ImageIcon icon12=new ImageIcon("src/Pictures/Virgin.png");
                                JOptionPane.showMessageDialog(null, "You are a Virgin","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon12);
                                break;
                            }
                            else if(birth > 30){
                                JOptionPane.showMessageDialog(null, "Please correct date","",JOptionPane.INFORMATION_MESSAGE);
                                break;
                            }
                            else
                                System.exit(0);
                        }
                        break;
                    case "September":
                        output= String.format("Your birth symbol is Virgins and Scales");
                        JOptionPane.showMessageDialog(null,output);
                        user=JOptionPane.showConfirmDialog(null,"Do you want find out if your Virgins and Scales (YES/NO)","User Option",JOptionPane.YES_NO_OPTION);
                        if(user== JOptionPane.YES_OPTION){
                            output= String.format("This section will tell your birthday symbol");
                            JOptionPane.showMessageDialog(null,output);
                            birthMonth=JOptionPane.showInputDialog(null,"Please enter the day of the month. Example 14");
                            int birth= Integer.parseInt(birthMonth);
                            if(birth <23){
                                ImageIcon icon12=new ImageIcon("src/Pictures/Virgin.png");
                                JOptionPane.showMessageDialog(null,"You are a Virgin","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon12);
                                break;
                            }
                            if (birth < 30){
                                ImageIcon icon13=new ImageIcon("src/Pictures/Scales.png");
                                JOptionPane.showMessageDialog(null, "You are a Scales","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon13);
                                break;
                            }
                            else if(birth > 30){
                                JOptionPane.showMessageDialog(null, "Please correct date","",JOptionPane.INFORMATION_MESSAGE);
                                break;
                            }
                            else
                                System.exit(0);
                        }
                        break;
                    case "October":
                        output= String.format("Your birth symbol is Scales and Scorpins");
                        JOptionPane.showMessageDialog(null,output);
                        user=JOptionPane.showConfirmDialog(null,"Do you want find out if your Scales or Scorpins (YES/NO)","User Option",JOptionPane.YES_NO_OPTION);
                        if(user== JOptionPane.YES_OPTION){
                            output= String.format("This section will tell your birthday symbol");
                            JOptionPane.showMessageDialog(null,output);
                            birthMonth=JOptionPane.showInputDialog(null,"Please enter the day of the month. Example 14");
                            int birth= Integer.parseInt(birthMonth);
                            if(birth <23){
                                ImageIcon icon13=new ImageIcon("src/Pictures/Scales.png");
                                JOptionPane.showMessageDialog(null, "You are a Scales","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon13);
                                break;
                            }
                            if (birth > 23){
                                ImageIcon icon14=new ImageIcon("src/Pitcures/Scorpin.png");
                                JOptionPane.showMessageDialog(null, "You are a Scorpins","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon14);
                                break;
                            }
                            else if(birth > 30){
                                JOptionPane.showMessageDialog(null, "Please correct date","",JOptionPane.INFORMATION_MESSAGE);
                                break;
                            }
                            else
                                System.exit(0);
                        }
                        break;
                    case "November":
                        output= String.format("Your birth symbol is Scorpins and Archers");
                        JOptionPane.showMessageDialog(null,output);
                        user=JOptionPane.showConfirmDialog(null,"Do you want find out if your Scoripin or Archers (YES/NO)","User Option",JOptionPane.YES_NO_OPTION);
                        if(user== JOptionPane.YES_OPTION){
                            output= String.format("This section will tell your birthday symbol");
                            JOptionPane.showMessageDialog(null,output);
                            birthMonth=JOptionPane.showInputDialog(null,"Please enter the day of the month. Example 14");
                            int birth= Integer.parseInt(birthMonth);
                            if(birth <22){
                                ImageIcon icon14=new ImageIcon("src/Pictures/Scorpin.png");
                                JOptionPane.showMessageDialog(null, "You are a Scorpins","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon14);
                                break;
                            }
                            if (birth > 22){
                                ImageIcon icon15 = new ImageIcon("src/Pictures/Archers.png");
                                JOptionPane.showMessageDialog(null, "You are a Archers","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon15);
                                break;
                            }
                            else if(birth > 31){
                                JOptionPane.showMessageDialog(null, "Please correct date","",JOptionPane.INFORMATION_MESSAGE);
                                break;
                            }
                            else
                                System.exit(0);
                        }
                        break;
                    case "December":
                        output= String.format("Your birth symbol is Archers and Goats");
                        JOptionPane.showMessageDialog(null,output);
                        user=JOptionPane.showConfirmDialog(null,"Do you want find out if your Archer or Goat (YES/NO)","User Option",JOptionPane.YES_NO_OPTION);
                        if(user== JOptionPane.YES_OPTION){
                            output= String.format("This section will tell your birthday symbol");
                            JOptionPane.showMessageDialog(null,output);
                            birthMonth=JOptionPane.showInputDialog(null,"Please enter the day of the month. Example 14");
                            int birth= Integer.parseInt(birthMonth);
                            if(birth < 21){
                                ImageIcon icon15 = new ImageIcon("src/Pictures/Archers.png");
                                JOptionPane.showMessageDialog(null, "You are a Archers","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon15);
                                break;
                            }
                            if (birth < 31){
                                ImageIcon icon16 =new ImageIcon("src/Pictures/Goat.png");
                                JOptionPane.showMessageDialog(null,"You are a Goat","Birthday Symbol",JOptionPane.PLAIN_MESSAGE,icon16);
                                break;
                            }
                            else if(birth > 31){
                                JOptionPane.showMessageDialog(null, "Please correct date","",JOptionPane.INFORMATION_MESSAGE);
                                break;
                            }
                            else
                                System.exit(0);
                        }
                        break;
                    default:
                        output= String.format("Invaild Statement try agian");
                        JOptionPane.showMessageDialog(null,output,"Error Message",JOptionPane.ERROR_MESSAGE);
                        break;
                }
            }
            /**
             * Exits the program.
             */
            else{
                System.exit(0);
            }
        }
        /**
         * Exits the program.
         */
        if(dateAction.getSource()==cancel){
            System.exit(0);
        }
        
        
    }
}

